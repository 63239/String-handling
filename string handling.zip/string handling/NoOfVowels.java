// input a word, output number of vowels and consonants
import java.util.Scanner;

public class NoOfVowels
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a word");
        String word = input.nextLine();
        int noOfVowels = 0;
        int i = 0;
        for (i = 0; i < word.length(); i++) {
            if (word.charAt(i)==('a') || (word.charAt(i)=='e') || (word.charAt(i)=='i') || (word.charAt(i)=='o') || (word.charAt(i)=='u') || (word.charAt(i)=='A') || (word.charAt(i)=='E') || (word.charAt(i)=='I') || (word.charAt(i)=='O') || (word.charAt(i)=='U')){
                noOfVowels++;
            }
        }
        int consonants = i - noOfVowels;
        System.out.print("There are " + noOfVowels + " vowels and " + consonants + " consonants in the word" + word);
    }
}