import java.util.Scanner;

public class wordGuesser
{
    public static void main(String[] args)
    {
        // Define word to be guessed
        Scanner input = new Scanner(System.in);
        String word = "RANDOM";
        String guess;
        // Variable correct is used to loop the program until they guess all characters correctly
        boolean correct = true;
        do {
            correct = true;
            // Making sure the guess is 6 characters and the users input is converted to uppercase
            do {
                System.out.println("Enter your guess of the 6 letter word");
                guess = input.nextLine();
                guess = guess.toUpperCase();
                System.out.println(guess);
                System.out.println(guess.length());
            } while (guess.length() != 6);
            
            //comparing each character of the string
            for (int i = 0; i < word.length(); i++) {
                if (word.charAt(i) == guess.charAt(i)) {
                    System.out.print(word.charAt(i));
                }
                else {
                    correct = false;
                    System.out.print("?");
                }
            }
            System.out.println("");
        } while (!correct);
    }
}