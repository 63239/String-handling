// input a string, output the characters in reverse order
import java.util.Scanner;

public class reverseString
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a scentence");
        String scentence = input.nextLine();
        int i = 0;
        for (i = 0; i < scentence.length(); i++){}
        while (i > 0) {
            i--;
            System.out.print(scentence.charAt(i));
        }
    }
}