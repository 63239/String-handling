// input first, middle and last name, output intials
import java.util.Scanner;

public class initials 
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter your first, middle and last name");
        String name = input.nextLine();
        name = (name.toUpperCase());
        if (name.length() > 0){
            System.out.print(name.charAt(0));
            for (int i = 0; i < name.length(); i++){
                if (name.charAt(i)==(' ')){
                    i++;
                    System.out.print(name.charAt(i));
                }
            }
        } else 
                    System.out.println("The string you entered was empty");
    }
}
       