// enter a password twice in a row, if they don't match input twice again.
import java.util.Scanner;

public class passwordVerification
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter your password");
        String password1 = input.nextLine();
        System.out.println("Enter your password again");
        String password2 = input.nextLine();
        if (password1.equals(password2)){
            System.out.println("Password Verified");
        }
        else {
            do {
                        System.out.println("Passwords do not match try again");
                        System.out.println("Enter your password");
                        password1 = input.nextLine();
                        System.out.println("Enter your password again");
                        password2 = input.nextLine();
            
        } while(!password1.equals(password2));
        System.out.println("Password Verified");
    }
}
}