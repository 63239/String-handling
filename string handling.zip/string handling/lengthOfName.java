//ask user to input name, find length of string
import java.util.Scanner;

public class lengthOfName
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter your name" );
        String yourName = input.nextLine();
        int length = yourName.length();
        System.out.println (length);
    }
}

