//input first and last name in one string, print hello and the last name on the same line
import java.util.Scanner;

public class splitString
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter your first and last name");
        String name = input.nextLine();
        int n = (name.indexOf(' '));
        n++;
        System.out.print("Hello ");
        for (int i = n; i < name.length(); i++){
            System.out.print(name.charAt(i));
        }
    }
}