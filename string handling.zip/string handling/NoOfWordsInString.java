// print number of words in a sentence
import java.util.Scanner;

public class NoOfWordsInString
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        int noWords = 1;
        System.out.println("Enter a phrase");
        String phrase = input.nextLine();
        for (int i = 0; i < phrase.length(); i++) {
            if (phrase.charAt(i)==(' ')){
                noWords++;
            }
        }
        System.out.println("The number of words in the phrase is " + noWords);
    }
}